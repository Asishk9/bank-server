-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: banking_system
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fixed_deposits`
--

DROP TABLE IF EXISTS `fixed_deposits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fixed_deposits` (
  `fd_id` int NOT NULL AUTO_INCREMENT,
  `account_id` int NOT NULL,
  `deposit_amount` decimal(15,2) NOT NULL,
  `interest_rate` decimal(5,2) NOT NULL,
  `tenure_months` int NOT NULL,
  `maturity_amount` decimal(15,2) DEFAULT NULL,
  `status` enum('Active','Closed','Premature') DEFAULT 'Active',
  `maturity_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `matured_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`fd_id`),
  KEY `fd_ibfk_1_idx` (`account_id`),
  CONSTRAINT `fd_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fixed_deposits`
--

LOCK TABLES `fixed_deposits` WRITE;
/*!40000 ALTER TABLE `fixed_deposits` DISABLE KEYS */;
INSERT INTO `fixed_deposits` VALUES (1,1,50000.00,6.50,12,53325.00,'Active','2025-03-21','2025-03-21 17:20:20',NULL),(2,2,100000.00,7.00,24,114490.00,'Closed','2027-03-21','2025-03-21 17:20:20',NULL),(3,3,200000.00,6.00,36,239486.00,'Active','2028-03-21','2025-03-21 17:20:20',NULL),(4,4,75000.00,6.80,18,81510.00,'Premature','2026-09-21','2025-03-21 17:20:20',NULL),(5,5,300000.00,7.50,60,435600.00,'Active','2030-03-21','2025-03-21 17:20:20',NULL),(15,24,10000.00,5.00,12,10500.00,'Active','2026-04-13','2025-04-13 11:16:17',NULL),(16,25,20000.00,4.00,12,20800.00,'Active','2026-04-13','2025-04-13 11:22:42',NULL),(17,26,100000.00,5.50,12,105500.00,'Active','2026-04-13','2025-04-13 13:11:09',NULL),(18,27,10000.00,5.00,12,10500.00,'Active','2026-04-13','2025-04-13 13:30:31',NULL),(21,47,10000.00,9.00,120,23673.64,'Active','2035-04-17','2025-04-17 18:19:33',NULL);
/*!40000 ALTER TABLE `fixed_deposits` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-08  7:43:00
