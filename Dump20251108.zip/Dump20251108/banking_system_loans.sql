-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: banking_system
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `loans`
--

DROP TABLE IF EXISTS `loans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `loans` (
  `loan_id` int NOT NULL AUTO_INCREMENT,
  `loan_amount` decimal(15,2) NOT NULL,
  `status` enum('Pending','Approved','Rejected','Closed') DEFAULT 'Pending',
  `loan_account_id` int NOT NULL,
  `loan_tenure` int NOT NULL,
  `interest_rate` decimal(5,2) NOT NULL,
  `installment_per_month` decimal(15,2) NOT NULL,
  `total_installments` int NOT NULL,
  `customer_id` int DEFAULT NULL,
  `applied_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `approved_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`loan_id`),
  UNIQUE KEY `loan_account_id_UNIQUE` (`loan_account_id`),
  KEY `loan_ibfk_2_idx` (`customer_id`),
  CONSTRAINT `loan_ibfk_1` FOREIGN KEY (`loan_account_id`) REFERENCES `accounts` (`account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loans`
--

LOCK TABLES `loans` WRITE;
/*!40000 ALTER TABLE `loans` DISABLE KEYS */;
INSERT INTO `loans` VALUES (1,500000.00,'Approved',3,60,10.50,10607.41,60,4,'2025-03-21 17:18:09',NULL),(2,1000000.00,'Pending',1,120,9.00,12500.00,120,13,'2025-03-21 17:18:09',NULL),(3,200000.00,'Approved',2,24,8.50,9166.67,24,13,'2025-03-21 17:18:09',NULL),(4,75000.00,'Rejected',4,12,12.00,6666.67,12,14,'2025-03-21 17:18:09',NULL),(5,250000.00,'Closed',5,48,11.00,7291.67,48,15,'2025-03-21 17:18:09',NULL),(7,10000.00,'Approved',34,12,8.00,900.00,12,4,'2025-04-14 17:03:45','2025-04-13 18:30:00'),(8,20000.00,'Pending',35,24,8.00,966.67,24,4,'2025-04-14 18:42:04',NULL),(9,1000.00,'Closed',36,1,9.00,1007.50,1,4,'2025-04-14 18:43:02','2025-04-14 18:30:00'),(10,100000.00,'Approved',37,12,8.00,9000.00,12,4,'2025-04-15 05:16:29','2025-04-14 18:30:00'),(11,100000.00,'Approved',42,36,7.00,3361.11,36,4,'2025-04-15 16:45:11','2025-04-14 18:30:00');
/*!40000 ALTER TABLE `loans` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-08  7:43:01
