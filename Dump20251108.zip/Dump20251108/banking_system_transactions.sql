-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: banking_system
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions` (
  `transaction_id` int NOT NULL AUTO_INCREMENT,
  `account_id` int NOT NULL,
  `transaction_type` enum('Credit','Debit') NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `final_balance` decimal(15,2) NOT NULL,
  `status` enum('Pending','Completed','Failed') DEFAULT 'Pending',
  `reference_number` varchar(50) DEFAULT NULL,
  `transaction_mode` enum('Cash','Card','UPI','Online') DEFAULT NULL,
  `transaction_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`transaction_id`),
  UNIQUE KEY `reference_number_UNIQUE` (`reference_number`),
  KEY `transactions_ibfk_1_idx` (`account_id`),
  CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (1,1,'Credit',5000.00,50000.00,'Completed','TXN10001','UPI','2025-03-21 17:19:43','Salary credit'),(2,2,'Debit',2000.00,148000.00,'Completed','TXN20002','UPI','2025-03-21 17:19:43','Utility bill payment'),(3,3,'Debit',10000.00,-260000.00,'Pending','TXN30003','Card','2025-03-21 17:19:43','Loan EMI payment'),(4,4,'Credit',10000.00,30000.00,'Completed','TXN40004','UPI','2025-03-21 17:19:43','Gift money'),(5,5,'Debit',25000.00,75000.00,'Failed','TXN50005','UPI','2025-03-21 17:19:43','Online purchase'),(6,4,'Debit',1000.00,18000.00,'Completed','UTR00171843015','Cash','2025-04-13 18:47:18',NULL),(7,4,'Credit',1000.00,19000.00,'Completed','UTR00183391900','Cash','2025-04-13 18:48:33',NULL),(8,4,'Credit',1000.00,20000.00,'Completed','UTR00194086815','Cash','2025-04-13 18:49:40',NULL),(9,4,'Debit',1000.00,19000.00,'Completed','UTR00202836276','Cash','2025-04-13 18:50:28',NULL),(10,4,'Credit',1000.00,20000.00,'Completed','UTR00205713832','Cash','2025-04-13 18:50:57',NULL),(11,4,'Debit',1000.00,19000.00,'Completed','UTR00360641518','Online','2025-04-13 19:06:06',NULL),(12,4,'Debit',2000.00,17000.00,'Completed','UTR00363470745','Online','2025-04-13 19:06:34',NULL),(13,4,'Credit',2000.00,19000.00,'Completed','UTR00365749744','Cash','2024-04-13 19:06:57',NULL),(14,4,'Debit',1000.00,18000.00,'Completed','UTR00511110901','Cash','2024-04-13 19:21:11',NULL),(15,4,'Credit',1000.00,19000.00,'Completed','UTR00512596396','Cash','2025-04-13 19:21:25',NULL),(16,4,'Debit',1000.00,18000.00,'Completed','UTR00513675413','Online','2025-04-13 19:21:36',NULL),(17,1,'Debit',1000.00,49000.00,'Completed','UTR10564757512','Cash','2025-04-15 05:26:47',NULL),(18,1,'Debit',1000.00,48000.00,'Completed','UTR10573991674','Online','2025-04-15 05:27:39',NULL),(19,4,'Debit',1000.00,17000.00,'Completed','UTR21410833596','Cash','2025-04-15 16:11:08',NULL),(20,1,'Debit',5000.00,43000.00,'Completed','UTR22134395229','Cash','2025-04-15 16:43:43',NULL),(21,1,'Debit',100.00,42900.00,'Completed','UTR23291412537','Cash','2025-04-17 17:59:14',NULL),(22,1,'Debit',100.00,42800.00,'Completed','UTR23323895882','Online','2025-04-17 18:02:38',NULL),(23,1,'Credit',1000.00,43800.00,'Completed','UTR15401965464','Cash','2025-04-18 10:10:19',NULL),(24,1,'Debit',100.00,43700.00,'Completed','UTR11234028013','Cash','2025-04-27 05:53:40',NULL),(25,1,'Debit',10.00,43690.00,'Completed','UTR11295912191','Cash','2025-04-27 05:59:59',NULL),(26,1,'Debit',10.00,43680.00,'Completed','UTR11355310052','Cash','2025-04-27 06:05:53',NULL),(27,1,'Credit',10.00,43690.00,'Completed','UTR11370181375','Cash','2025-04-27 06:07:01',NULL),(28,1,'Debit',1000.00,42690.00,'Completed','UTR11481431290','Cash','2025-04-27 06:18:14',NULL),(29,1,'Credit',100.00,42790.00,'Completed','UTR11500174731','Cash','2025-04-27 06:20:01',NULL),(30,1,'Credit',10.00,42800.00,'Completed','UTR11504955810','Cash','2025-04-27 06:20:49',NULL),(31,1,'Debit',1000.00,41800.00,'Completed','UTR12375076860','Cash','2025-04-27 07:07:50',NULL),(32,1,'Debit',21.00,41779.00,'Completed','UTR13064751537','Cash','2025-04-27 07:36:47',NULL),(33,2,'Debit',100.00,149900.00,'Completed','UTR13182563232','Online','2025-04-27 07:48:25',NULL),(34,2,'Debit',56.00,149844.00,'Completed','UTR13211360992','Online','2025-04-27 07:51:13',NULL),(35,2,'Debit',10.00,149834.00,'Completed','UTR13272195262','Online','2025-04-27 07:57:21',NULL),(36,44,'Credit',10.00,610.00,'Completed','UTR13272158451','Online','2025-04-27 07:57:21',NULL),(37,2,'Debit',50.00,149784.00,'Completed','UTR13275812314','Online','2025-04-27 07:57:58',NULL),(38,44,'Credit',50.00,660.00,'Completed','UTR13275894096','Online','2025-04-27 07:57:58',NULL),(39,2,'Debit',10.00,149774.00,'Completed','UTR13302974943','Online','2025-04-27 08:00:29',NULL),(40,44,'Credit',10.00,670.00,'Completed','UTR13302950347','Online','2025-04-27 08:00:29',NULL),(41,2,'Debit',1000.00,148774.00,'Completed','UTR13310159511','Online','2025-04-27 08:01:01',NULL),(42,2,'Credit',1000.00,150774.00,'Completed','UTR13310160833','Online','2025-04-27 08:01:01',NULL),(43,1,'Debit',1000.00,40779.00,'Completed','UTR13314769927','Online','2025-04-27 08:01:47',NULL),(44,2,'Credit',1000.00,150774.00,'Completed','UTR13314732423','Online','2025-04-27 08:01:47',NULL),(45,1,'Debit',100.00,40679.00,'Completed','UTR13340324734','Online','2025-04-27 08:04:03','Transfer to account 0520451828'),(46,2,'Credit',100.00,150874.00,'Completed','UTR13340346287','Online','2025-04-27 08:04:03','Transfer from account 0885973382'),(47,1,'Debit',100.00,40579.00,'Completed','UTR13361453444','Cash','2025-04-27 08:06:14','Withdrawal through Cash'),(48,1,'Credit',100.00,40679.00,'Completed','UTR13362594179','Cash','2025-04-27 08:06:25','Deposit through Cash'),(49,1,'Credit',100.00,40779.00,'Completed','UTR13404049739','Cash','2025-04-27 08:10:40','Deposit through Cash'),(50,1,'Debit',100.00,40679.00,'Completed','UTR13412745737','Cash','2025-04-27 08:11:27','Withdrawal through Cash'),(51,1,'Debit',100.00,40579.00,'Completed','UTR13414560530','Online','2025-04-27 08:11:45','Transfer to account 0520451828'),(52,2,'Credit',100.00,150974.00,'Completed','UTR13414585505','Online','2025-04-27 08:11:45','Transfer from account 0885973382'),(53,2,'Debit',100.00,150874.00,'Completed','UTR13445045821','Online','2025-04-27 08:14:50','Transfer to account 0520451828'),(54,2,'Credit',100.00,151074.00,'Completed','UTR13445059206','Online','2025-04-27 08:14:50','Transfer from account 0520451828'),(55,2,'Debit',100.00,150874.00,'Completed','UTR13454659001','Online','2025-04-27 08:15:46','Transfer to account 0520451828'),(56,2,'Credit',100.00,151074.00,'Completed','UTR13454699802','Online','2025-04-27 08:15:46','Transfer from account 0520451828'),(57,2,'Debit',100.00,150874.00,'Completed','UTR13464566622','Online','2025-04-27 08:16:45','Transfer to account 0520451828'),(58,2,'Credit',100.00,151074.00,'Completed','UTR13464557401','Online','2025-04-27 08:16:45','Transfer from account 0520451828'),(59,2,'Debit',10.00,150964.00,'Completed','UTR13483165491','Online','2025-04-27 08:18:31','Transfer to account 0520451828'),(60,2,'Credit',10.00,150984.00,'Completed','UTR13483132286','Online','2025-04-27 08:18:31','Transfer from account 0520451828'),(61,1,'Debit',10.00,40569.00,'Completed','UTR14200847679','Cash','2025-04-27 08:50:08','Withdrawal through Cash');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-08  7:43:01
