-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: banking_system
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `branches`
--

DROP TABLE IF EXISTS `branches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `branches` (
  `branch_id` int NOT NULL AUTO_INCREMENT,
  `branch_name` varchar(50) NOT NULL,
  `branch_code` varchar(20) NOT NULL,
  `address` text,
  `city_id` int DEFAULT NULL,
  `pincode` varchar(6) DEFAULT NULL,
  `phone` varchar(10) NOT NULL,
  `bm_id` int DEFAULT NULL,
  `rm_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`branch_id`),
  UNIQUE KEY `branch_code_UNIQUE` (`branch_code`),
  UNIQUE KEY `phone_UNIQUE` (`phone`),
  KEY `users_ibfk_1_idx` (`rm_id`),
  KEY `users_ibfk_2_idx` (`bm_id`),
  KEY `users_ibfk_3_idx` (`city_id`),
  CONSTRAINT `branch_ibfk_1` FOREIGN KEY (`rm_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `branch_ibfk_2` FOREIGN KEY (`bm_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `branch_ibfk_3` FOREIGN KEY (`city_id`) REFERENCES `city` (`city_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branches`
--

LOCK TABLES `branches` WRITE;
/*!40000 ALTER TABLE `branches` DISABLE KEYS */;
INSERT INTO `branches` VALUES (0,'Temporary Branch','GBI1000',NULL,NULL,NULL,'N/A',NULL,NULL,'2025-04-11 06:38:22','2025-04-14 12:14:25'),(1,'Lucknow Branch','GBI1001','Hazratganj, Lucknow',658,'226001','9123456789',2,1,'2025-03-21 17:16:24','2025-04-12 09:27:15'),(2,'Mumbai Branch','GBI1002','Bandra, Mumbai',363,'400050','9123456790',5,1,'2025-03-21 17:16:24','2025-04-12 09:27:15'),(3,'Bangalore Branch','GBI1003','MG Road, Bangalore',249,'560001','9123456791',6,1,'2025-03-21 17:16:24','2025-04-12 09:27:15'),(4,'Chennai Branch','GBI1004','T Nagar, Chennai',532,'600017','9123456792',7,1,'2025-03-21 17:16:24','2025-04-12 09:27:15'),(5,'Delhi Branch','GBI1005','Connaught Place, Delhi',727,'110001','9123456793',8,1,'2025-03-21 17:16:24','2025-04-26 15:36:31'),(6,'Indore Branch','GBI1006','Gol Chauraha',314,'242321','7637862189',0,1,'2025-04-11 09:28:40','2025-04-26 13:40:08');
/*!40000 ALTER TABLE `branches` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-08  7:43:00
