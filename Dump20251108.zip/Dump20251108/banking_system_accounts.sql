-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: banking_system
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts` (
  `account_id` int NOT NULL AUTO_INCREMENT,
  `account_no` varchar(20) NOT NULL,
  `customer_id` int NOT NULL,
  `branch_id` int NOT NULL,
  `account_type` enum('savings','current','loan','fixed_deposit') NOT NULL,
  `balance` decimal(15,2) DEFAULT '0.00',
  `interest_rate` decimal(5,2) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `closed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`account_id`),
  KEY `account_ibfk_1_idx` (`customer_id`),
  KEY `account_ibfk_2_idx` (`branch_id`),
  CONSTRAINT `account_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `account_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`branch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES (1,'0885973382',4,1,'savings',40569.00,3.50,0,'2025-03-21 17:17:42',NULL),(2,'0520451828',4,2,'current',150974.00,0.00,1,'2025-03-21 17:17:42',NULL),(3,'0754862362',4,1,'loan',-249900.00,10.00,1,'2024-03-21 17:17:42',NULL),(4,'0207220970',13,4,'current',17000.00,3.50,1,'2025-03-21 17:17:42',NULL),(5,'0673957327',13,1,'fixed_deposit',100000.00,6.50,1,'2025-03-21 17:17:42',NULL),(7,'0528002837',20,1,'savings',10000.00,6.50,1,'2025-04-12 18:01:43',NULL),(8,'0647428604',21,1,'current',2000.00,0.00,1,'2025-04-12 18:22:51',NULL),(9,'0675024736',21,1,'savings',2000.00,0.00,1,'2025-04-12 18:26:42',NULL),(12,'0647090781',22,3,'current',10000.00,0.00,1,'2025-04-12 20:21:01',NULL),(13,'0323263323',23,0,'savings',6099.00,3.00,1,'2025-04-12 20:24:55',NULL),(14,'0790569959',23,1,'current',100.00,0.00,1,'2025-04-12 20:28:09',NULL),(23,'0181135257',5,2,'fixed_deposit',100000.00,5.50,1,'2025-04-13 11:08:36',NULL),(24,'0946403214',4,1,'fixed_deposit',10000.00,5.00,1,'2025-04-13 11:16:17',NULL),(25,'0922424885',4,1,'fixed_deposit',20000.00,4.00,1,'2025-04-13 11:22:42',NULL),(26,'0685618033',4,1,'fixed_deposit',100000.00,5.50,1,'2025-04-13 13:11:09',NULL),(27,'0914097130',4,1,'fixed_deposit',10000.00,5.00,1,'2025-04-13 13:30:31',NULL),(34,'0871142274',4,1,'loan',0.00,0.00,1,'2025-04-14 17:03:44',NULL),(35,'0178397800',4,1,'loan',0.00,0.00,1,'2025-04-14 18:42:04',NULL),(36,'0852089474',4,1,'loan',0.00,0.00,1,'2025-04-14 18:43:02',NULL),(37,'0236331731',4,1,'loan',0.00,0.00,1,'2025-04-15 05:16:28',NULL),(42,'0167662278',4,1,'loan',0.00,0.00,1,'2025-04-15 16:45:10',NULL),(43,'0705750462',32,1,'savings',10000.00,5.00,1,'2025-04-16 20:30:51',NULL),(44,'0789143782',35,1,'savings',670.00,3.00,1,'2025-04-16 21:15:44',NULL),(45,'0622715111',36,1,'savings',1000.00,3.00,1,'2025-04-16 21:27:01',NULL),(46,'0755349639',38,1,'savings',1000.00,3.00,1,'2025-04-17 06:47:31',NULL),(47,'0439436733',4,1,'fixed_deposit',10000.00,9.00,1,'2025-04-17 18:19:33',NULL),(48,'0052535018',90,1,'savings',500.00,3.00,1,'2025-04-27 08:58:56',NULL);
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-08  7:43:01
